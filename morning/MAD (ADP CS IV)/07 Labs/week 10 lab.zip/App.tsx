import React, { useState } from 'react';
import {
  SafeAreaView,
  ScrollView,
  StatusBar,
  StyleSheet,
  Text,
  TextInput,
  TouchableOpacity,
  View,
} from 'react-native';

type Task = {
  id: number;
  title: string;
  done: boolean;
};

function TaskItem({
  task,
  onToggle,
}: {
  task: Task;
  onToggle: (id: number) => void;
}) {
  // console.log lets us trace re-renders in the Metro/terminal logs
  console.log(`Rendering TaskItem: ${task.title}`);

  return (
    <TouchableOpacity style={styles.taskRow} onPress={() => onToggle(task.id)}>
      <Text style={[styles.taskText, task.done && styles.taskDone]}>
        {task.done ? '✅ ' : '⬜ '}
        {task.title}
      </Text>
    </TouchableOpacity>
  );
}

function App(): React.JSX.Element {
  const [tasks, setTasks] = useState<Task[]>([
    { id: 1, title: 'Learn Flutter unit testing', done: false },
    { id: 2, title: 'Learn React Native debugging', done: false },
    { id: 3, title: 'Test on a physical device', done: false },
  ]);
  const [newTaskTitle, setNewTaskTitle] = useState('');
  const [counter, setCounter] = useState(0);

  // ----- BUG #1: Stale closure -----
  // This handler captures `counter` from the render in which it was created.
  // setTimeout fires later, using the OLD value of `counter`, not the latest one.
  // Use React DevTools' "counter" state value + console logs to prove this.
  const handleDelayedIncrement = () => {
    setTimeout(() => {
      console.log('Stale closure bug -> counter at click time was:', counter);
      setCounter(counter + 1); // BUG: should use functional update setCounter(c => c + 1)
    }, 3000);
  };

  const toggleTask = (id: number) => {
    setTasks(prev =>
      prev.map(t => (t.id === id ? { ...t, done: !t.done } : t)),
    );
  };

  const addTask = () => {
    if (newTaskTitle.trim().length === 0) return;
    setTasks(prev => [
      ...prev,
      { id: Date.now(), title: newTaskTitle.trim(), done: false },
    ]);
    setNewTaskTitle('');
  };

  return (
    <SafeAreaView style={styles.container}>
      <StatusBar barStyle="dark-content" />
      <ScrollView contentInsetAdjustmentBehavior="automatic">
        <Text style={styles.header}>RN Debug Demo</Text>

        <View style={styles.counterBox}>
          <Text style={styles.counterText}>Counter: {counter}</Text>
          <TouchableOpacity
            style={styles.button}
            onPress={handleDelayedIncrement}>
            <Text style={styles.buttonText}>
              Increment after 3s (buggy)
            </Text>
          </TouchableOpacity>
        </View>

        <View style={styles.inputRow}>
          <TextInput
            style={styles.input}
            placeholder="New task title"
            value={newTaskTitle}
            onChangeText={setNewTaskTitle}
          />
          <TouchableOpacity style={styles.addButton} onPress={addTask}>
            <Text style={styles.buttonText}>Add</Text>
          </TouchableOpacity>
        </View>

        {tasks.map(task => (
          <TaskItem key={task.id} task={task} onToggle={toggleTask} />
        ))}
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#fff' },
  header: { fontSize: 24, fontWeight: 'bold', textAlign: 'center', marginVertical: 16 },
  counterBox: { alignItems: 'center', marginBottom: 20 },
  counterText: { fontSize: 18, marginBottom: 8 },
  button: { backgroundColor: '#2563eb', padding: 10, borderRadius: 8 },
  addButton: { backgroundColor: '#16a34a', padding: 10, borderRadius: 8, marginLeft: 8 },
  buttonText: { color: '#fff', fontWeight: '600' },
  inputRow: { flexDirection: 'row', marginHorizontal: 16, marginBottom: 16, alignItems: 'center' },
  input: { flex: 1, borderWidth: 1, borderColor: '#ccc', borderRadius: 8, padding: 8 },
  taskRow: { padding: 14, marginHorizontal: 16, marginBottom: 8, backgroundColor: '#f1f5f9', borderRadius: 8 },
  taskText: { fontSize: 16 },
  taskDone: { textDecorationLine: 'line-through', color: '#888' },
});

export default App;
