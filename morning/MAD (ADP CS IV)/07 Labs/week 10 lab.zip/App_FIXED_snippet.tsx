// FIXED VERSION — apply this change after completing the debugging exercise.
// Only the relevant function is shown; replace it inside App.tsx.

const handleDelayedIncrement = () => {
  setTimeout(() => {
    // Functional update form: React passes in the LATEST state value (c),
    // instead of relying on the `counter` variable captured by this closure.
    setCounter(c => {
      console.log('Fixed version -> latest counter was:', c);
      return c + 1;
    });
  }, 3000);
};
