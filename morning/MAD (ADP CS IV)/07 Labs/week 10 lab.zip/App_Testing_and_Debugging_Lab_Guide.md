# App Testing and Debugging — Complete Student Lab Guide

**Topics covered:** Unit Testing & Widget Testing in Flutter · Debugging a React Native App with React DevTools · Testing Apps on Physical Devices

**Lab Tasks:**
1. Write unit tests for a Flutter counter app
2. Debug a React Native app using React DevTools
3. Test apps on physical devices

---

## Table of Contents

1. [Concepts: Why We Test and Debug Apps](#1-concepts)
2. [Part A — Flutter Setup](#2-part-a-flutter-setup)
3. [Part A — Building the Counter App](#3-part-a-building-the-counter-app)
4. [Part A — Unit Testing the Counter Logic](#4-part-a-unit-testing)
5. [Part A — Widget Testing the Counter UI](#5-part-a-widget-testing)
6. [Part A — Running and Reading Test Results](#6-part-a-running-tests)
7. [Part B — React Native Setup](#7-part-b-react-native-setup)
8. [Part B — Building a Buggy Sample App](#8-part-b-buggy-app)
9. [Part B — Debugging with React DevTools](#9-part-b-react-devtools)
10. [Part C — Testing on Physical Devices](#10-part-c-physical-devices)
11. [Lab Report Checklist & Viva Questions](#11-checklist)
12. [Troubleshooting Reference](#12-troubleshooting)

---

<a name="1-concepts"></a>
## 1. Concepts: Why We Test and Debug Apps

Before writing code, every student should understand the vocabulary used throughout this lab.

| Term | Meaning |
|---|---|
| **Unit Test** | Tests a single function, method, or class in isolation — no UI, no device. Fast and cheap to run. |
| **Widget Test** | Tests a single Flutter widget's UI and behavior in a simulated environment (no real device needed), e.g. tapping a button and checking the screen updates. |
| **Integration Test** | Tests the whole app (or a large part of it) running on a real or emulated device, simulating real user flows. *(Not covered in depth here, but mentioned for context.)* |
| **Debugging** | The process of finding and fixing defects (bugs) in running code, using breakpoints, logs, and inspection tools. |
| **React DevTools** | A browser/standalone tool that lets you inspect the React (and React Native) component tree, props, state, and re-renders. |
| **Physical Device Testing** | Running and testing the app on a real phone/tablet instead of an emulator/simulator, to catch real-world issues (performance, sensors, camera, GPS, screen sizes). |

**The Testing Pyramid** (why we write many unit tests, fewer widget tests, and even fewer end-to-end tests):

```
        /\
       /  \      Few:  End-to-End / Integration Tests (slow, full app)
      /----\
     /      \    Some: Widget Tests (medium speed, single UI components)
    /--------\
   /          \  Many: Unit Tests (fast, single functions/classes)
  /------------\
```

---

<a name="2-part-a-flutter-setup"></a>
## 2. Part A — Flutter Setup (Initial Environment)

### 2.1 Install Prerequisites

| Requirement | Notes |
|---|---|
| OS | Windows 10/11, macOS, or Linux |
| Disk space | At least 2.8 GB (more with Android Studio) |
| Git | Required to install Flutter SDK |
| Android Studio | For Android emulator + SDK tools (or Xcode on macOS for iOS) |
| A code editor | VS Code (recommended) with the **Flutter** and **Dart** extensions |

### 2.2 Install the Flutter SDK

1. Download the Flutter SDK from `https://docs.flutter.dev/get-started/install` for your OS.
2. Extract it to a permanent location, e.g.:
   - Windows: `C:\src\flutter`
   - macOS/Linux: `~/development/flutter`
3. Add Flutter to your system `PATH`:

   **Windows (PowerShell, run once):**
   ```powershell
   setx PATH "$($Env:PATH);C:\src\flutter\bin"
   ```

   **macOS/Linux (add to `~/.zshrc` or `~/.bashrc`):**
   ```bash
   export PATH="$PATH:$HOME/development/flutter/bin"
   ```

4. Verify installation and check for missing dependencies:
   ```bash
   flutter doctor
   ```
   `flutter doctor` will print a checklist (✓ / ✗) for Flutter SDK, Android toolchain, Xcode (macOS only), VS Code, and connected devices. **Fix every ✗ before continuing.** Common fixes:
   - Android licenses not accepted → `flutter doctor --android-licenses` (accept all with `y`)
   - Android Studio not found → install it from `https://developer.android.com/studio`

### 2.3 Install VS Code Extensions

In VS Code, open the Extensions panel (`Ctrl+Shift+X` / `Cmd+Shift+X`) and install:
- **Flutter** (this also installs the Dart extension automatically)

### 2.4 Create the Project

```bash
flutter create flutter_counter_app
cd flutter_counter_app
flutter pub get
```

This scaffolds a ready-to-run counter app, which we will modify slightly to make it testable and instructive.

### 2.5 Project Structure You Should See

```
flutter_counter_app/
├── lib/
│   └── main.dart
├── test/
│   └── widget_test.dart      (Flutter auto-generates a starter test file)
├── pubspec.yaml
└── ...
```

---

<a name="3-part-a-building-the-counter-app"></a>
## 3. Part A — Building the Counter App

We will slightly restructure the default counter app to separate **logic** (a `Counter` class) from **UI** (the `CounterPage` widget). This separation is exactly *why* unit testing and widget testing are different things — logic is tested with unit tests, UI is tested with widget tests.

### 3.1 `lib/counter.dart` — the pure logic class (unit-testable)

```dart
/// A simple counter class containing only business logic.
/// No Flutter/UI imports here on purpose — this is what makes
/// it possible to unit test it quickly, without a UI engine.
class Counter {
  int _value = 0;

  int get value => _value;

  void increment() {
    _value++;
  }

  void decrement() {
    // Prevent the counter from going below zero (a deliberate business rule
    // so we have something meaningful to test).
    if (_value > 0) {
      _value--;
    }
  }

  void reset() {
    _value = 0;
  }
}
```

### 3.2 `lib/main.dart` — the UI, using `Counter`

```dart
import 'package:flutter/material.dart';
import 'counter.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Counter App',
      theme: ThemeData(primarySwatch: Colors.blue),
      home: const CounterPage(title: 'Flutter Counter Demo'),
    );
  }
}

class CounterPage extends StatefulWidget {
  const CounterPage({super.key, required this.title});

  final String title;

  @override
  State<CounterPage> createState() => _CounterPageState();
}

class _CounterPageState extends State<CounterPage> {
  final Counter _counter = Counter();

  void _increment() {
    setState(() {
      _counter.increment();
    });
  }

  void _decrement() {
    setState(() {
      _counter.decrement();
    });
  }

  void _reset() {
    setState(() {
      _counter.reset();
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text(widget.title)),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: <Widget>[
            const Text('You have pushed the button this many times:'),
            Text(
              '${_counter.value}',
              key: const Key('counterValueText'),
              style: Theme.of(context).textTheme.headlineMedium,
            ),
            const SizedBox(height: 20),
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                ElevatedButton(
                  key: const Key('decrementButton'),
                  onPressed: _decrement,
                  child: const Icon(Icons.remove),
                ),
                const SizedBox(width: 16),
                ElevatedButton(
                  key: const Key('resetButton'),
                  onPressed: _reset,
                  child: const Text('Reset'),
                ),
              ],
            ),
          ],
        ),
      ),
      floatingActionButton: FloatingActionButton(
        key: const Key('incrementButton'),
        onPressed: _increment,
        tooltip: 'Increment',
        child: const Icon(Icons.add),
      ),
    );
  }
}
```

> **Why the `Key(...)` on widgets?** Keys let widget tests reliably find a specific widget (e.g., the counter text or a button) instead of guessing by widget type or text content, which is fragile if the UI text changes later.

### 3.3 Run the app to confirm it works before testing

```bash
flutter run
```
Tap **+** to increment, **−** to decrement (it should never go below 0), and **Reset** to zero it. Confirm this manually first — never write tests against an app you haven't seen working.

---

<a name="4-part-a-unit-testing"></a>
## 4. Part A — Unit Testing the Counter Logic

Unit tests check the `Counter` class **without** touching any UI. They use the `test` package (already included by `flutter_test`/`flutter create`).

### 4.1 Add/confirm the dependency in `pubspec.yaml`

```yaml
dev_dependencies:
  flutter_test:
    sdk: flutter
  test: ^1.24.0
```

Then run:
```bash
flutter pub get
```

### 4.2 Create `test/counter_test.dart`

```dart
import 'package:flutter_test/flutter_test.dart';
import 'package:flutter_counter_app/counter.dart';

void main() {
  group('Counter class - unit tests', () {
    late Counter counter;

    // setUp runs before EACH test, so every test starts from a clean state.
    setUp(() {
      counter = Counter();
    });

    test('initial value should be 0', () {
      expect(counter.value, 0);
    });

    test('increment should increase value by 1', () {
      counter.increment();
      expect(counter.value, 1);
    });

    test('increment called 3 times should give value 3', () {
      counter.increment();
      counter.increment();
      counter.increment();
      expect(counter.value, 3);
    });

    test('decrement should decrease value by 1', () {
      counter.increment(); // value = 1
      counter.decrement(); // value = 0
      expect(counter.value, 0);
    });

    test('decrement should never go below 0', () {
      counter.decrement(); // already at 0, should stay 0
      expect(counter.value, 0);
    });

    test('reset should set value back to 0', () {
      counter.increment();
      counter.increment();
      counter.reset();
      expect(counter.value, 0);
    });
  });
}
```

> **Note:** Replace `flutter_counter_app` in the import with whatever name appears as `name:` at the top of your `pubspec.yaml` if it differs.

### 4.3 What each part means (for your lab report)

| Code | Meaning |
|---|---|
| `group(...)` | Bundles related tests together under a readable label in test output |
| `setUp(...)` | Runs before every test in the group — ensures test isolation |
| `test('description', () { ... })` | A single test case; the description should read like a sentence |
| `expect(actual, expected)` | The assertion — fails the test if `actual` doesn't match `expected` |

---

<a name="5-part-a-widget-testing"></a>
## 5. Part A — Widget Testing the Counter UI

Widget tests run the UI in an in-memory test environment (`WidgetTester`), simulate taps, and check what's rendered on screen — all without needing an emulator or physical device.

### 5.1 Replace `test/widget_test.dart` with the following

```dart
import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:flutter_counter_app/main.dart';

void main() {
  group('CounterPage - widget tests', () {
    testWidgets('starts at 0 and shows the increment, decrement, reset buttons',
        (WidgetTester tester) async {
      // Build the widget tree and trigger a frame.
      await tester.pumpWidget(const MyApp());

      // Verify initial state.
      expect(find.text('0'), findsOneWidget);
      expect(find.byKey(const Key('incrementButton')), findsOneWidget);
      expect(find.byKey(const Key('decrementButton')), findsOneWidget);
      expect(find.byKey(const Key('resetButton')), findsOneWidget);
    });

    testWidgets('tapping + increments the counter', (WidgetTester tester) async {
      await tester.pumpWidget(const MyApp());

      expect(find.text('0'), findsOneWidget);

      // Tap the '+' floating action button.
      await tester.tap(find.byKey(const Key('incrementButton')));
      // Rebuild the widget after the state change.
      await tester.pump();

      expect(find.text('1'), findsOneWidget);
      expect(find.text('0'), findsNothing);
    });

    testWidgets('tapping + three times shows 3', (WidgetTester tester) async {
      await tester.pumpWidget(const MyApp());

      final incrementButton = find.byKey(const Key('incrementButton'));
      await tester.tap(incrementButton);
      await tester.pump();
      await tester.tap(incrementButton);
      await tester.pump();
      await tester.tap(incrementButton);
      await tester.pump();

      expect(find.text('3'), findsOneWidget);
    });

    testWidgets('tapping - never goes below 0', (WidgetTester tester) async {
      await tester.pumpWidget(const MyApp());

      await tester.tap(find.byKey(const Key('decrementButton')));
      await tester.pump();

      expect(find.text('0'), findsOneWidget);
    });

    testWidgets('reset sets counter back to 0', (WidgetTester tester) async {
      await tester.pumpWidget(const MyApp());

      final incrementButton = find.byKey(const Key('incrementButton'));
      await tester.tap(incrementButton);
      await tester.pump();
      await tester.tap(incrementButton);
      await tester.pump();
      expect(find.text('2'), findsOneWidget);

      await tester.tap(find.byKey(const Key('resetButton')));
      await tester.pump();

      expect(find.text('0'), findsOneWidget);
    });
  });
}
```

### 5.2 Key widget-test API explained

| API | Meaning |
|---|---|
| `tester.pumpWidget(widget)` | Builds the widget tree for the first time (like launching the app) |
| `tester.pump()` | Rebuilds the widget tree after a state change (like `setState`) |
| `find.text('0')` | Locates a widget displaying the exact text `'0'` |
| `find.byKey(Key('...'))` | Locates a widget by its unique `Key` |
| `tester.tap(finder)` | Simulates a user tap on the found widget |
| `findsOneWidget` / `findsNothing` | Assertion matchers for how many matching widgets exist |

---

<a name="6-part-a-running-tests"></a>
## 6. Part A — Running and Reading Test Results

### 6.1 Run all tests

```bash
flutter test
```

### 6.2 Run a single file

```bash
flutter test test/counter_test.dart
flutter test test/widget_test.dart
```

### 6.3 Run with coverage (optional, good for lab reports)

```bash
flutter test --coverage
```
This generates `coverage/lcov.info`. To view it as HTML (requires `lcov` installed):
```bash
genhtml coverage/lcov.info -o coverage/html
```
Then open `coverage/html/index.html` in a browser.

### 6.4 Reading output

A passing run looks like:
```
00:01 +11: All tests passed!
```
A failing test shows the expected vs. actual value, e.g.:
```
Expected: 1
  Actual: 0

   package:test  expect
test/counter_test.dart 15:5  main.<fn>.<fn>
```

**Lab exercise:** Deliberately break `Counter.increment()` (e.g., change `_value++` to `_value--`), rerun `flutter test`, and screenshot the failure. Then fix it back and screenshot the pass. Include both in your report — this demonstrates you understand what a failing assertion looks like, not just a passing one.

---

<a name="7-part-b-react-native-setup"></a>
## 7. Part B — React Native Setup (Initial Environment)

We will use the **React Native CLI** workflow (not Expo) since it gives full access to native debugging tools, which this lab requires.

### 7.1 Prerequisites

| Requirement | All OS | Notes |
|---|---|---|
| Node.js | ✓ | LTS version (≥18), check with `node -v` |
| Watchman (macOS) | ✓ (mac only) | `brew install watchman` |
| Java Development Kit (JDK 17) | ✓ | Required for Android builds |
| Android Studio | ✓ | Provides Android SDK + emulator |
| Xcode (macOS only) | macOS only | For iOS builds/simulator |

### 7.2 Environment Variables (Android, all platforms)

Add to your shell profile (`~/.bashrc`, `~/.zshrc`, or Windows Environment Variables):
```bash
export ANDROID_HOME=$HOME/Library/Android/sdk      # macOS path example
export PATH=$PATH:$ANDROID_HOME/emulator
export PATH=$PATH:$ANDROID_HOME/platform-tools
```

### 7.3 Create the Project

```bash
npx react-native init RNDebugDemo
cd RNDebugDemo
```

This scaffolds a working app with `App.tsx` as the entry point.

### 7.4 Verify the Setup

```bash
npx react-native doctor
```
Fix any ✗ items before proceeding (similar philosophy to `flutter doctor`).

### 7.5 Run It

**Android (emulator or device must be connected):**
```bash
npx react-native run-android
```

**iOS (macOS only):**
```bash
npx react-native run-ios
```

If the Metro bundler doesn't start automatically:
```bash
npx react-native start
```

---

<a name="8-part-b-buggy-app"></a>
## 8. Part B — Building a Buggy Sample App

To make debugging meaningful, we build a small app with **two intentional bugs**: one state bug (stale closure) and one prop-drilling/re-render issue — both are classic problems React DevTools is built to catch.

### 8.1 Replace `App.tsx`

```tsx
import React, { useState } from 'react';
import {
  SafeAreaView,
  ScrollView,
  StatusBar,
  StyleSheet,
  Text,
  TextInput,
  TouchableOpacity,
  View,
} from 'react-native';

type Task = {
  id: number;
  title: string;
  done: boolean;
};

function TaskItem({
  task,
  onToggle,
}: {
  task: Task;
  onToggle: (id: number) => void;
}) {
  // console.log lets us trace re-renders in the Metro/terminal logs
  console.log(`Rendering TaskItem: ${task.title}`);

  return (
    <TouchableOpacity style={styles.taskRow} onPress={() => onToggle(task.id)}>
      <Text style={[styles.taskText, task.done && styles.taskDone]}>
        {task.done ? '✅ ' : '⬜ '}
        {task.title}
      </Text>
    </TouchableOpacity>
  );
}

function App(): React.JSX.Element {
  const [tasks, setTasks] = useState<Task[]>([
    { id: 1, title: 'Learn Flutter unit testing', done: false },
    { id: 2, title: 'Learn React Native debugging', done: false },
    { id: 3, title: 'Test on a physical device', done: false },
  ]);
  const [newTaskTitle, setNewTaskTitle] = useState('');
  const [counter, setCounter] = useState(0);

  // ----- BUG #1: Stale closure -----
  // This handler captures `counter` from the render in which it was created.
  // setTimeout fires later, using the OLD value of `counter`, not the latest one.
  // Use React DevTools' "counter" state value + console logs to prove this.
  const handleDelayedIncrement = () => {
    setTimeout(() => {
      console.log('Stale closure bug -> counter at click time was:', counter);
      setCounter(counter + 1); // BUG: should use functional update setCounter(c => c + 1)
    }, 3000);
  };

  const toggleTask = (id: number) => {
    setTasks(prev =>
      prev.map(t => (t.id === id ? { ...t, done: !t.done } : t)),
    );
  };

  const addTask = () => {
    if (newTaskTitle.trim().length === 0) return;
    setTasks(prev => [
      ...prev,
      { id: Date.now(), title: newTaskTitle.trim(), done: false },
    ]);
    setNewTaskTitle('');
  };

  return (
    <SafeAreaView style={styles.container}>
      <StatusBar barStyle="dark-content" />
      <ScrollView contentInsetAdjustmentBehavior="automatic">
        <Text style={styles.header}>RN Debug Demo</Text>

        <View style={styles.counterBox}>
          <Text style={styles.counterText}>Counter: {counter}</Text>
          <TouchableOpacity
            style={styles.button}
            onPress={handleDelayedIncrement}>
            <Text style={styles.buttonText}>
              Increment after 3s (buggy)
            </Text>
          </TouchableOpacity>
        </View>

        <View style={styles.inputRow}>
          <TextInput
            style={styles.input}
            placeholder="New task title"
            value={newTaskTitle}
            onChangeText={setNewTaskTitle}
          />
          <TouchableOpacity style={styles.addButton} onPress={addTask}>
            <Text style={styles.buttonText}>Add</Text>
          </TouchableOpacity>
        </View>

        {tasks.map(task => (
          <TaskItem key={task.id} task={task} onToggle={toggleTask} />
        ))}
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#fff' },
  header: { fontSize: 24, fontWeight: 'bold', textAlign: 'center', marginVertical: 16 },
  counterBox: { alignItems: 'center', marginBottom: 20 },
  counterText: { fontSize: 18, marginBottom: 8 },
  button: { backgroundColor: '#2563eb', padding: 10, borderRadius: 8 },
  addButton: { backgroundColor: '#16a34a', padding: 10, borderRadius: 8, marginLeft: 8 },
  buttonText: { color: '#fff', fontWeight: '600' },
  inputRow: { flexDirection: 'row', marginHorizontal: 16, marginBottom: 16, alignItems: 'center' },
  input: { flex: 1, borderWidth: 1, borderColor: '#ccc', borderRadius: 8, padding: 8 },
  taskRow: { padding: 14, marginHorizontal: 16, marginBottom: 8, backgroundColor: '#f1f5f9', borderRadius: 8 },
  taskText: { fontSize: 16 },
  taskDone: { textDecorationLine: 'line-through', color: '#888' },
});

export default App;
```

### 8.2 What's deliberately wrong (for the lab report)

| Bug | Where | Symptom |
|---|---|---|
| **Stale closure** | `handleDelayedIncrement` | Clicking the button rapidly multiple times within 3 seconds only increments the counter once overall, because every queued `setTimeout` callback "remembers" the same old `counter` value at the time it was created. |
| **Unnecessary re-renders** | `TaskItem` console log | Toggling **one** task re-renders only that one item correctly (good!) — but if a student adds an unrelated piece of state to `App` carelessly, *all* `TaskItem`s re-render. Watching the `console.log` lines (or the React DevTools **"Highlight updates when components render"** option) demonstrates this. |

---

<a name="9-part-b-react-devtools"></a>
## 9. Part B — Debugging with React DevTools

### 9.1 Install React DevTools (standalone app — required for React Native, since there's no browser DOM)

```bash
npm install -g react-devtools
```

### 9.2 Launch it

```bash
react-devtools
```

A standalone window opens with **Components** and **Profiler** tabs and waits for your app to connect.

### 9.3 Connect your React Native app

1. Make sure Metro bundler is running:
   ```bash
   npx react-native start
   ```
2. Run the app on a simulator/emulator/device (it auto-connects to `react-devtools` on the default port, 8097).
3. If it doesn't auto-connect, open the **in-app Dev Menu**:
   - Android emulator: `Cmd/Ctrl + M` or shake gesture
   - iOS simulator: `Cmd + D`
   - Physical device: shake the device
   Then tap **"Open Debugger"** / ensure Dev settings allow JS debugging, and reload the app (`R, R` on Android or `Cmd+R` on iOS simulator).

### 9.4 Step-by-step debugging walkthrough

**Step 1 — Inspect the component tree**
- In React DevTools, click the **Components** tab.
- Expand the tree: `App > ScrollView > TaskItem`. Click a `TaskItem` and observe its **props** panel on the right (`task`, `onToggle`) — confirm `task.done` toggles `true`/`false` when you tap it on the device.

**Step 2 — Inspect and edit state live**
- Click on `App` in the component tree.
- In the right panel, find the `hooks` section showing `State: 0` for `counter` and the `tasks` array for the `useState` hook.
- **Live-edit** the `counter` value directly in DevTools (double-click the value) and watch the on-screen `Counter: X` text update instantly — this proves DevTools state edits flow straight into the live UI.

**Step 3 — Catch the stale closure bug**
1. Tap **"Increment after 3s (buggy)"** three times quickly (within 3 seconds).
2. Watch the `counter` state in the **Components** panel after all three timeouts fire.
3. **Expected (if correct):** `counter` should be `3`.
4. **Actual (buggy):** `counter` is `1`, because each `setTimeout` closure captured the same stale `counter = 0`.
5. Confirm via the Metro terminal logs — you'll see three lines all printing `"counter at click time was: 0"`.

**The fix** (have students apply this and re-test):
```tsx
const handleDelayedIncrement = () => {
  setTimeout(() => {
    setCounter(c => c + 1); // functional update reads the LATEST state, not a stale closure
  }, 3000);
};
```
Re-run the same 3-tap test; `counter` should now correctly read `3`.

**Step 4 — Catch unnecessary re-renders using the Profiler**
1. Switch to the **Profiler** tab in React DevTools.
2. Click the record (●) button.
3. Tap one `TaskItem` to toggle it.
4. Stop recording.
5. The flame graph shows which components re-rendered during that interaction. **Expected:** only the tapped `TaskItem` (and `App`, since its state changed) should show as rendered — siblings should be greyed out / not re-rendered, because of the `key`-based, isolated mapping.
6. Toggle **"Highlight updates when components render"** (gear icon ⚙ in DevTools settings) to see this visually on the live app as flashing borders around re-rendered components in real time.

**Step 5 — Use console logs alongside DevTools**
- The `console.log` statements inside `TaskItem` print to your terminal where Metro is running. Cross-reference these logs with what DevTools' Profiler shows to build confidence in the diagnosis — this is the standard "two tools triangulating one bug" debugging workflow professionals use.

### 9.5 Summary table of what to capture for the lab report

| Screenshot / Evidence | What it should show |
|---|---|
| Components tree | `App > TaskItem` hierarchy with props panel visible |
| State live-edit | Before/after of manually editing `counter` value in DevTools |
| Stale closure bug reproduction | Three rapid taps → counter only reaches 1, terminal logs showing repeated stale value |
| Stale closure fix confirmation | Same three taps → counter correctly reaches 3 |
| Profiler flame graph | Before and after toggling a task, showing which components re-rendered |

---

<a name="10-part-c-physical-devices"></a>
## 10. Part C — Testing on Physical Devices

### 10.1 Flutter on a physical Android device

1. **Enable Developer Options** on the phone: Settings → About phone → tap "Build number" 7 times.
2. **Enable USB debugging**: Settings → Developer options → toggle "USB debugging" on.
3. Connect the phone via USB cable. Accept the **"Allow USB debugging?"** prompt on the phone.
4. Verify the device is recognized:
   ```bash
   flutter devices
   ```
   You should see your device listed with its model name and an ID.
5. Run the app directly on it:
   ```bash
   flutter run -d <device_id>
   ```
6. Hot reload still works on physical devices: press `r` in the terminal to hot reload, `R` for hot restart.

### 10.2 Flutter on a physical iOS device (macOS only)

1. Connect the iPhone via USB/cable.
2. Open `ios/Runner.xcworkspace` in Xcode at least once to set up code signing (select your Apple ID team under Signing & Capabilities).
3. Trust the computer on the iPhone when prompted.
4. Run:
   ```bash
   flutter devices
   flutter run -d <device_id>
   ```
5. On the phone, you may need to go to Settings → General → VPN & Device Management → trust the developer certificate the first time.

### 10.3 React Native on a physical Android device

1. Enable Developer Options + USB debugging (same as 10.1, steps 1–2).
2. Connect via USB, accept the debugging prompt.
3. Confirm ADB sees it:
   ```bash
   adb devices
   ```
   Output should show the device serial with `device` status (not `unauthorized`).
4. Run:
   ```bash
   npx react-native run-android
   ```
   This builds and installs directly onto the connected phone (no emulator used).
5. To open the Dev Menu on the device: **shake the phone**, or run:
   ```bash
   adb shell input keyevent 82
   ```

### 10.4 React Native on a physical iOS device (macOS + paid/free Apple Developer account)

1. Connect the iPhone, open `ios/RNDebugDemo.xcworkspace` in Xcode.
2. Select your device as the run target in Xcode's device dropdown.
3. Under Signing & Capabilities, select your Apple ID/team.
4. Press the Run (▶) button in Xcode, or:
   ```bash
   npx react-native run-ios --device "Your iPhone Name"
   ```
5. Trust the developer certificate on the device on first run (Settings → General → VPN & Device Management).

### 10.5 Why physical device testing matters (include this reasoning in your report)

| Emulator/Simulator Limitation | What a Physical Device Reveals |
|---|---|
| Simulated CPU/GPU performance, often faster than real hardware | True frame rate, jank, and animation smoothness |
| No real camera/GPS/accelerometer/biometric sensors (or fake data) | Actual sensor behavior, camera permissions flow, GPS accuracy |
| Unlimited fake "RAM" in some configurations | Real memory pressure and low-memory app kills |
| No real cellular network conditions | True latency, offline behavior, real Wi-Fi/4G/5G switching |
| Different default device sizes from your actual target users | True screen size/notch/safe-area issues |
| No real battery drain feedback | Actual battery and thermal impact of your app |

### 10.6 Physical Device Test Checklist (run through this for both apps)

- [ ] App installs and launches without crashing
- [ ] All interactive elements (buttons, inputs) respond correctly to touch
- [ ] Layout looks correct on the device's actual screen size/notch
- [ ] Hot reload (Flutter) / Fast Refresh (RN) works while connected via USB
- [ ] App behaves correctly when device is rotated (if orientation is supported)
- [ ] No console errors/warnings appear during normal usage
- [ ] App performance feels smooth (no visible lag tapping buttons)

---

<a name="11-checklist"></a>
## 11. Lab Report Checklist & Viva Questions

### What to submit
1. Source code (`flutter_counter_app/` and `RNDebugDemo/`, or a GitHub link).
2. Screenshot of `flutter test` passing (all green, "All tests passed!").
3. Screenshot of one deliberately-failed test (broken logic) and its fix.
4. Screenshots from React DevTools: Components tree, state live-edit, Profiler flame graph.
5. Screenshots/notes proving the stale closure bug was reproduced and fixed.
6. Screenshot of `flutter devices` / `adb devices` showing a real physical device connected.
7. A short paragraph (5–10 sentences) reflecting on one bug you personally found and fixed.

### Sample viva / quiz questions

1. What is the difference between a unit test and a widget test in Flutter?
2. Why does the `Counter` class in this lab not import any Flutter UI packages?
3. What does `tester.pump()` do, and why is it needed after `tester.tap()`?
4. What is a "stale closure" in JavaScript/React, and how do you fix it?
5. How does the Profiler tab in React DevTools help detect unnecessary re-renders?
6. Name two things a physical device test can reveal that an emulator cannot.
7. What command checks whether your Flutter environment is correctly configured?

---

<a name="12-troubleshooting"></a>
## 12. Troubleshooting Reference

| Problem | Likely Cause | Fix |
|---|---|---|
| `flutter doctor` shows Android license errors | Licenses not accepted | `flutter doctor --android-licenses`, accept all |
| `flutter test` can't find `package:flutter_counter_app/...` | Package name mismatch | Check `name:` field in `pubspec.yaml` matches your import |
| Widget test fails with "found 0 widgets" | Missing `await tester.pump()` after a tap | Add `pump()` after every state-changing action |
| React Native app won't connect to DevTools | Metro not running, or wrong port | Start Metro with `npx react-native start`, ensure port 8097 is free |
| `adb devices` shows "unauthorized" | USB debugging prompt not accepted on phone | Reconnect cable, tap "Allow" on the device prompt |
| iOS physical device build fails with signing error | No valid Apple Developer team selected | Open Xcode → Signing & Capabilities → select your Apple ID |
| App builds for emulator but not physical device | Different architecture/missing device drivers (Android) | Install OEM USB drivers, ensure `adb devices` sees the phone first |
| Hot reload doesn't trigger automatically | File watcher issue | Use hot restart, or check that Metro/Flutter terminal session is active |

---

*End of Lab Guide. Students should work through Parts A → B → C in order, verifying each app works manually before writing or running any tests.*
