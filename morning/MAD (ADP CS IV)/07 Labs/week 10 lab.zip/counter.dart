/// A simple counter class containing only business logic.
/// No Flutter/UI imports here on purpose — this is what makes
/// it possible to unit test it quickly, without a UI engine.
class Counter {
  int _value = 0;

  int get value => _value;

  void increment() {
    _value++;
  }

  void decrement() {
    // Prevent the counter from going below zero (a deliberate business rule
    // so we have something meaningful to test).
    if (_value > 0) {
      _value--;
    }
  }

  void reset() {
    _value = 0;
  }
}
