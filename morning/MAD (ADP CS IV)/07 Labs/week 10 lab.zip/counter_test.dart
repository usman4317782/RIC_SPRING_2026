import 'package:flutter_test/flutter_test.dart';
import 'package:flutter_counter_app/counter.dart';

void main() {
  group('Counter class - unit tests', () {
    late Counter counter;

    // setUp runs before EACH test, so every test starts from a clean state.
    setUp(() {
      counter = Counter();
    });

    test('initial value should be 0', () {
      expect(counter.value, 0);
    });

    test('increment should increase value by 1', () {
      counter.increment();
      expect(counter.value, 1);
    });

    test('increment called 3 times should give value 3', () {
      counter.increment();
      counter.increment();
      counter.increment();
      expect(counter.value, 3);
    });

    test('decrement should decrease value by 1', () {
      counter.increment(); // value = 1
      counter.decrement(); // value = 0
      expect(counter.value, 0);
    });

    test('decrement should never go below 0', () {
      counter.decrement(); // already at 0, should stay 0
      expect(counter.value, 0);
    });

    test('reset should set value back to 0', () {
      counter.increment();
      counter.increment();
      counter.reset();
      expect(counter.value, 0);
    });
  });
}
