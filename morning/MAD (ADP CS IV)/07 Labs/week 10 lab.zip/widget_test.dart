import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:flutter_counter_app/main.dart';

void main() {
  group('CounterPage - widget tests', () {
    testWidgets('starts at 0 and shows the increment, decrement, reset buttons',
        (WidgetTester tester) async {
      // Build the widget tree and trigger a frame.
      await tester.pumpWidget(const MyApp());

      // Verify initial state.
      expect(find.text('0'), findsOneWidget);
      expect(find.byKey(const Key('incrementButton')), findsOneWidget);
      expect(find.byKey(const Key('decrementButton')), findsOneWidget);
      expect(find.byKey(const Key('resetButton')), findsOneWidget);
    });

    testWidgets('tapping + increments the counter', (WidgetTester tester) async {
      await tester.pumpWidget(const MyApp());

      expect(find.text('0'), findsOneWidget);

      // Tap the '+' floating action button.
      await tester.tap(find.byKey(const Key('incrementButton')));
      // Rebuild the widget after the state change.
      await tester.pump();

      expect(find.text('1'), findsOneWidget);
      expect(find.text('0'), findsNothing);
    });

    testWidgets('tapping + three times shows 3', (WidgetTester tester) async {
      await tester.pumpWidget(const MyApp());

      final incrementButton = find.byKey(const Key('incrementButton'));
      await tester.tap(incrementButton);
      await tester.pump();
      await tester.tap(incrementButton);
      await tester.pump();
      await tester.tap(incrementButton);
      await tester.pump();

      expect(find.text('3'), findsOneWidget);
    });

    testWidgets('tapping - never goes below 0', (WidgetTester tester) async {
      await tester.pumpWidget(const MyApp());

      await tester.tap(find.byKey(const Key('decrementButton')));
      await tester.pump();

      expect(find.text('0'), findsOneWidget);
    });

    testWidgets('reset sets counter back to 0', (WidgetTester tester) async {
      await tester.pumpWidget(const MyApp());

      final incrementButton = find.byKey(const Key('incrementButton'));
      await tester.tap(incrementButton);
      await tester.pump();
      await tester.tap(incrementButton);
      await tester.pump();
      expect(find.text('2'), findsOneWidget);

      await tester.tap(find.byKey(const Key('resetButton')));
      await tester.pump();

      expect(find.text('0'), findsOneWidget);
    });
  });
}
